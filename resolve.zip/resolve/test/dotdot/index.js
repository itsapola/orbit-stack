module.exports = 'whatever';
