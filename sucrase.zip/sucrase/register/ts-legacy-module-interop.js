require("../dist/register").registerTSLegacyModuleInterop();
