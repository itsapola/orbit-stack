# Installation
> `npm install --save @types/yargs`

# Summary
This package contains type definitions for yargs (https://github.com/chevex/yargs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yargs/v13.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 16:32:05 GMT
 * Dependencies: [@types/yargs-parser](https://npmjs.com/package/@types/yargs-parser)
 * Global values: none

# Credits
These definitions were written by [Martin Poelstra](https://github.com/poelstra), [Mizunashi Mana](https://github.com/mizunashi-mana), [Jeffery Grajkowski](https://github.com/pushplay), [Jimi (Dimitris) Charalampidis](https://github.com/JimiC), [Steffen Viken Valvåg](https://github.com/steffenvv), [Emily Marigold Klassen](https://github.com/forivall), and [ExE Boss](https://github.com/ExE-Boss).
