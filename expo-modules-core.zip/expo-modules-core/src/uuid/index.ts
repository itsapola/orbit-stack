export { default } from './uuid';
