'use strict';

require('./shim')();
