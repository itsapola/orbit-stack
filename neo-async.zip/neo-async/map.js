'use strict';

module.exports = require('./async').map;
